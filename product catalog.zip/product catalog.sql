 CREATE TABLE categories (
    category_id INT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL
);

INSERT INTO categories (category_id, category_name) VALUES
(1, 'Electronics'),
(2, 'Clothing'),
(3, 'Books'),
(4, 'Home & Kitchen'),
(5, 'Beauty & Personal Care'),
(6, 'Toys & Games'),
(7, 'Sports & Outdoors'),
(8, 'Automotive'),
(9, 'Grocery & Gourmet Food'),
(10, 'Health & Household');

CREATE TABLE products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    stock_quantity INT DEFAULT 0,
    category_id INT,
    FOREIGN KEY (category_id) REFERENCES categories(category_id)
);

INSERT INTO products (product_id, product_name, description, price, stock_quantity, category_id) VALUES
(101, 'Smartphone X200', 'Latest 5G smartphone with AMOLED display', 699.99, 50, 1),
(102, 'Bluetooth Headphones', 'Wireless over-ear headphones with noise cancellation', 129.99, 100, 1),
(103, 'Men\'s Denim Jacket', 'Stylish denim jacket for men', 59.99, 75, 2),
(104, 'Cookbook: 100 Easy Recipes', 'A bestselling cookbook with healthy recipes', 24.99, 200, 3),
(105, 'Non-stick Frying Pan', '12-inch frying pan with non-stick coating', 34.50, 150, 4),
(106, 'Face Moisturizer', 'Hydrating face cream for all skin types', 19.95, 80, 5),
(107, 'Lego Classic Box', 'Creative building blocks set for kids', 49.99, 60, 6),
(108, 'Yoga Mat', 'Anti-slip mat for yoga and workouts', 29.99, 40, 7),
(109, 'Car Vacuum Cleaner', 'Portable vacuum cleaner for car interiors', 39.99, 30, 8),
(110, 'Organic Green Tea', '100 tea bags of organic green tea', 15.99, 120, 9);


CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(15),
    address TEXT
);

INSERT INTO customers (customer_id, customer_name, email, phone, address) VALUES
(1, 'Alice Johnson', 'alice.johnson@example.com', '9876543210', '123 Maple Street, New York, NY'),
(2, 'Bob Smith', 'bob.smith@example.com', '8765432109', '456 Oak Avenue, Los Angeles, CA'),
(3, 'Charlie Brown', 'charlie.brown@example.com', '7654321098', '789 Pine Road, Chicago, IL'),
(4, 'Diana Prince', 'diana.prince@example.com', '6543210987', '1010 Elm St, Seattle, WA'),
(5, 'Ethan Clark', 'ethan.clark@example.com', '5432109876', '2020 Willow Lane, Boston, MA'),
(6, 'Fiona Davis', 'fiona.davis@example.com', '4321098765', '3030 Cedar Blvd, Miami, FL'),
(7, 'George Hill', 'george.hill@example.com', '3210987654', '4040 Birch Dr, Austin, TX'),
(8, 'Hannah Lee', 'hannah.lee@example.com', '2109876543', '5050 Spruce Ct, Denver, CO'),
(9, 'Isaac Wong', 'isaac.wong@example.com', '1098765432', '6060 Cherry Pl, Atlanta, GA'),
(10, 'Jenna Patel', 'jenna.patel@example.com', '9988776655', '7070 Poplar Ave, San Diego, CA');



CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    order_date DATE,
    status VARCHAR(50),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

INSERT INTO orders (order_id, customer_id, order_date, status) VALUES
(1001, 1, DATE '2025-07-01', 'Shipped'),
(1002, 2, DATE '2025-07-02', 'Processing'),
(1003, 3, DATE '2025-07-02', 'Delivered'),
(1004, 4, DATE '2025-07-03', 'Cancelled'),
(1005, 5, DATE '2025-07-03', 'Shipped'),
(1006, 6, DATE '2025-07-04', 'Processing'),
(1007, 7, DATE '2025-07-04', 'Delivered'),
(1008, 8, DATE '2025-07-05', 'Shipped'),
(1009, 9, DATE '2025-07-06', 'Delivered'),
(1010, 10, DATE '2025-07-06', 'Processing');


CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY,
    order_id INT,
    product_id INT,
    quantity INT,
    price_at_purchase DECIMAL(10, 2),
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

INSERT INTO order_items (order_item_id, order_id, product_id, quantity, price_at_purchase) VALUES
(1, 1001, 101, 1, 699.99),   -- Smartphone X200
(2, 1001, 102, 2, 129.99),   -- Bluetooth Headphones
(3, 1002, 103, 1, 59.99),    -- Men's Denim Jacket
(4, 1003, 104, 3, 24.99),    -- Cookbook
(5, 1004, 105, 1, 34.50),    -- Frying Pan
(6, 1005, 106, 2, 19.95),    -- Moisturizer
(7, 1006, 107, 1, 49.99),    -- Lego Set
(8, 1007, 108, 1, 29.99),    -- Yoga Mat
(9, 1008, 109, 1, 39.99),    -- Car Vacuum
(10, 1009, 110, 2, 15.99);   -- Green Tea


CREATE TABLE suppliers (
    supplier_id INT PRIMARY KEY,
    supplier_name VARCHAR(100),
    contact_info TEXT
);

INSERT INTO suppliers (supplier_id, supplier_name, contact_info) VALUES
(1, 'TechZone Inc.', 'techzone@example.com, +1-800-123-4567'),
(2, 'Urban Wear Co.', 'urbanwear@example.com, +1-800-234-5678'),
(3, 'Gourmet Publishers', 'gourmetpub@example.com, +1-800-345-6789'),
(4, 'HomeEssentials Ltd.', 'homeessentials@example.com, +1-800-456-7890'),
(5, 'BeautyBloom', 'beautybloom@example.com, +1-800-567-8901'),
(6, 'FunToys Corp.', 'funtoys@example.com, +1-800-678-9012'),
(7, 'FitLife Supplies', 'fitlife@example.com, +1-800-789-0123'),
(8, 'AutoPro Tools', 'autopro@example.com, +1-800-890-1234'),
(9, 'GreenLeaf Organics', 'greenleaf@example.com, +1-800-901-2345'),
(10, 'MediHealth', 'medihealth@example.com, +1-800-012-3456');


-- queries
SELECT 
    p.product_id, 
    p.product_name, 
    c.category_name, 
    p.price, 
    p.stock_quantity
FROM products p
JOIN categories c ON p.category_id = c.category_id;

-- queries

SELECT 
    o.order_id, 
    c.customer_name, 
    o.order_date, 
    o.status
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id;
 
 
 -- view
CREATE VIEW view_order_summary AS
SELECT 
    o.order_id,
    c.customer_name,
    o.order_date,
    o.status,
    SUM(oi.quantity * oi.price_at_purchase) AS total_amount
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
JOIN order_items oi ON o.order_id = oi.order_id
GROUP BY o.order_id, c.customer_name, o.order_date, o.status;

-- view

CREATE VIEW view_product_sales AS
SELECT 
    p.product_id,
    p.product_name,
    SUM(oi.quantity) AS total_units_sold,
    SUM(oi.quantity * oi.price_at_purchase) AS total_revenue
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
GROUP BY p.product_id, p.product_name;
 
 -- procedure
 DELIMITER //

CREATE PROCEDURE add_product (
    IN p_name VARCHAR(100),
    IN p_description TEXT,
    IN p_price DECIMAL(10,2),
    IN p_stock INT,
    IN p_category_id INT,
    IN p_supplier_id INT
)
BEGIN
    INSERT INTO products (product_name, description, price, stock_quantity, category_id, supplier_id)
    VALUES (p_name, p_description, p_price, p_stock, p_category_id, p_supplier_id);
END //

DELIMITER ;

-- procedure
DELIMITER //

CREATE PROCEDURE update_stock (
    IN p_product_id INT,
    IN p_new_stock INT
)
BEGIN
    UPDATE products
    SET stock_quantity = p_new_stock
    WHERE product_id = p_product_id;
END //

DELIMITER ;

-- Trigger
DELIMITER //

CREATE TRIGGER trg_reduce_stock
AFTER INSERT ON order_items
FOR EACH ROW
BEGIN
    UPDATE products
    SET stock_quantity = stock_quantity - NEW.quantity
    WHERE product_id = NEW.product_id;
END //

DELIMITER ;

-- Trigger
DELIMITER //

CREATE TRIGGER trg_check_stock
BEFORE INSERT ON order_items
FOR EACH ROW
BEGIN
    DECLARE current_stock INT;

    SELECT stock_quantity INTO current_stock
    FROM products
    WHERE product_id = NEW.product_id;

    IF current_stock < NEW.quantity THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Not enough stock available for this product';
    END IF;
END //

DELIMITER ;


 


